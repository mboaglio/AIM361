from __future__ import absolute_import

RULE_CONFIG_FILE = "rule_config_jsons/ruleConfigs.json"
RULE_GROUPS_CONFIG_FILE = "rule_config_jsons/ruleGroups.json"
COLLECTION_CONFIG_FILE = "rule_config_jsons/collections.json"
